import matplotlib.pyplot as plt
import sympy as sp
from sympy.parsing.sympy_parser import parse_expr
from sympy import Symbol, sympify, diff, Subs

def Lf(f, fp, fp2, xn):
    x = Symbol("x")
    fn = f.subs(x, xn)
    fpn = fp.subs(x, xn)**2
    fp2n = fp2.subs(x, xn)
    return (fn*fp2n)/fpn

def sne_ud_1(fstr, x0, tol, graf): # super-Halley

    """
    Evalua una funcion dependiente de X para asi encontrar una aproximacion
    de una de sus raices.

    Recuperado de "Geometric constructions of iterative functions to solve
        nonlinear equations"    
    Autores "S.Amat, S.Busquier, J.M. Guti"

    Retorna una lista donde sus elementos son el x aproximado y la cantidad de
    iteraciones necesarias para cumplir con la tolerancia dada

    parametros:
    fstr: funcion dependdiente de x a la cual se le quiere encontrar sus ceros
    x0: valor inicial para empezar a calcular las iteraciones
    tol: tolerancia aceptable para finalizar el metodo
    graf: parametro para indicar si se quiere generar la grafica

    Ejemplo sne_ud_1('x**2-4*x+4', 5, 0.00001, 1)
    
    """

    x = Symbol("x")
    try:
        f = sympify(fstr)
    except ValueError:
        return 'Syntaxis de la funcion incorrecta'
    fp = diff(f,x)
    fp2 = diff(fp, x)
    itera = 0
    xAprox = x0
    xAx = []
    yAx = []
    while (abs(f.subs(x, xAprox)) >= tol):
        xAx += [itera]
        yAx += [abs(f.subs(x, xAprox))]
        try:
            fpxn = 1/(fp.subs(x, xAprox))
            fpxn = fpxn**(-1)
        except ValueError:
            break
        fxn = f.subs(x, xAprox)
        Lfxn = Lf(f, fp, fp2, xAprox)
        xAprox = xAprox - (1+0.5*(Lfxn/(1-Lfxn)))*(fxn/fpxn)
        itera += 1
    if (graf):
        plt.plot(xAx, yAx)
        plt.title('Comportamiento del metodo de Super-Halley para ' + fstr) 
        plt.xlabel('iteraciones')
        plt.ylabel('|f(Xaprox)|')
        plt.grid(True)
        plt.show()
        return [xAprox, itera]
    else:
        return [xAprox, itera]


print(sne_ud_1('x**2-4*x+4', 5, 0.00001, 1))


def getyk(funcion, xk, a):
    numerador = evaluar(funcion, xk)
    denominador = evaluar(calDerivada(funcion), xk)
    yk = xk - a*(numerador/abs(denominador))
    return yk


def getxk(funcion, x):
    a = 1
    a1 = 1
    a2 = 1
    b1 = 1
    b2 = 1
    yk = getyk(funcion, x, a)
    fx = evaluar(funcion, x)
    fy = evaluar(funcion, yk)
    fdx = evaluar(calDerivada(funcion), x)
    operando1 = fx/abs((a1*fx)+(a2*fy))
    operando2 = ((b1*fx)+(b2*fy))/abs(fx)
    xk = yk-(operando1+operando2)*(fy/abs(fdx))
    return xk


def sne_ud_2(funcion, x0, tol, graf):
    """ Version del metodo iterativo Ostrowski–Chun, con un valor de alfa = alfa1 = beta1= beta =1
        Recuperado del documento "Solving nonlinear problems by Ostrowski–Chun type
        parametric families" creado por 
   Alicia Cordero, Javier G. Maimó Juan R. Torregrosa · María P. Vassileva. 
   
   Intenta lograr valores de conversion mediante la ecuacion (5) del documento.
   Parametros: 
    1) funcion: Funcion en formato string en terminos de x la cual require la aproximacion
    2) x0: Valor inicial de la funcion necesario para las siguientes aproximaciones
    3) tol: Tolerancia al error maxima para el cÃ¡lculo de la aproximacion
    4) graf: Bandera para realizar o no el grafico de iteraciones vs aproximacion.
   Probado con sne_ud_2("(x**3)-4*(x**2)-10", 1, 0.000001, 1)
   
    """
    x = sp.symbols('x')
    try:
        fun_sim = parse_expr(funcion)
    except:
        print('Error de sintaxis')
    xk = getxk(funcion, x0)
    k = 1  # Corresponde a la iteración en que se encuentra
    listaX = [0]
    listaY = [x0]
    listaY.append(xk)
    listaX.append(1)
    while (error(funcion, xk) >= tol):
        xk = getxk(funcion, xk)
        xk1 = getxk(funcion, xk)
        listaY.append(xk)
        listaY.append(xk1)
        k += 2
        listaX.append(k-1)
        listaX.append(k)

    if (graf == 0):
        return imprimirResultado(listaX[-1], listaY[-1])
    else:
        print(listaX, listaY)
        imprimirResultado(listaX[-1], listaY[-1])
        return graficar(listaX, listaY, "Ostrowski")


def sne_ud_5(func, x0, tol, graf):
    """    
    Método de Liu-Wang, utilizando alfa_1 = 5 y alfa_2 = -7, así como la función sne_ud_5("sin(x)^2-x^2+1",1.5,0.0001,1) con x_0 = 1.5
    Recuperado del documento "A stable class of improved second-derivative free
    Chebyshev-Halley type methods with optimal eighth order convergence" creado por 
    Alicia Cordero, Munish Kansal, Vinay Kanwar y Juan R. Torregrosa.
    Parametros: 
        1) func: Funcion en formato string en terminos de x la cual require la aproximacion
        2) x0: Valor inicial de la funcion necesario para las siguientes aproximaciones
        3) tol: Tolerancia al error maxima para el cálculo de la aproximacion
        4) graf: Bandera para realizar o no el grafico de iteraciones vs aproximacion.
    """
    x = Symbol("x")
    try:
        f = sympify(func)
        firstDerivate = diff(f, x)
    except:
        print("Syntax Error")
        return
    xAxis = []
    yAxis = []
    aprox = x0
    iteration = 1
    while (abs(f.subs(x, aprox)) >= tol):
        functionAprox = f.subs(x, aprox)
        firstDerivateAprox = firstDerivate.subs(x, aprox)
        try:
            yn = aprox - functionAprox/firstDerivateAprox
            functionOnYn = f.subs(x, yn)
            divisor = N(functionAprox/functionAprox-2*functionOnYn)
            zn = yn - N((divisor)*functionOnYn/firstDerivateAprox)
            functionOnZn = f.subs(x, zn)
            temp = N(zn - ((functionAprox-functionOnYn/functionAprox-2*functionOnYn)**2 + (functionOnZn/functionOnYn -
                                                                                           5*functionOnZn) + (4*functionOnZn/functionAprox+-7*functionOnZn))*N(functionOnZn/firstDerivateAprox))
        except:
            break
        aprox = temp
        xAxis += [iteration]
        yAxis += [f.subs(x, aprox)]
        iteration += 1

    if (graf == 1):
       plt.plot(xAxis, yAxis)
       plt.title(
           'Iteration vs aproximation graph using a tol value of: ' + str(tol))
       plt.xlabel("iterations")
       plt.ylabel("Aproximation")
       plt.show()
       return [aprox, iteration]
    else:
        return "Iteration numeber:" + str(iteration) + " Aproximation value: " + str(aprox)


def sne_ud_4(func, x0, tol, graf):
    """
    Método de Halley con convergencia cúbica.
    Recuperado del documento "Geometric constructions of iterative functions to solve
    nonlinear equations" creado por S.Amata, S.Busquiera, J.M. Gutierrez
    Parametros: 
        1) func: Funcion en formato string en terminos de x la cual require la aproximacion
        2) x0: Valor inicial de la funcion necesario para las siguientes aproximaciones
        3) tol: Tolerancia al error maxima para el cรกlculo de la aproximacion
        4) graf: Bandera para realizar o no el grafico de iteraciones vs aproximacion.
    Probado con la funcion sne_ud_4("x^3 -4*x^2-10",1,0.0001,1) con x_0 = 1
    """
    x = Symbol("x")
    try:
        f = sympify(func)
        firstDerivate = diff(f, x)
        secondDerivate = diff(firstDerivate, x)
    except:
        print("Syntax Error")
        return
    xAxis = []
    yAxis = []
    aprox = x0
    iteration = 1
    while (abs(f.subs(x, aprox)) >= tol):
        functionAprox = f.subs(x, aprox)
        firstDerivateAprox = firstDerivate.subs(x, aprox)
        try:
            lF = Lf(f, firstDerivate, secondDerivate, aprox)
            temp = aprox - (2/2-lF)*functionAprox/firstDerivateAprox
        except:
            break
        aprox = temp
        xAxis += [iteration]
        yAxis += [f.subs(x, aprox)]
        iteration += 1

    if (graf == 1):
        plt.plot(xAxis, yAxis)
        plt.title(
            'Iteration vs aproximation graph using a tol value of: ' + str(tol))
        plt.xlabel("iterations")
        plt.ylabel("Aproximation")
        plt.show()
        return [aprox, iteration]
    else:
        textResult = "Iteration numeber:" + \
            str(iteration) + " Aproximation value: " + str(aprox)
        return textResult


def sne_ud_3(func, x0, tol, graf):
    """
    Version optimizada del metodo iterativo Chebyshev-Halley, con un valor de alfa = 1
    Recuperado del documento "A stable class of improved second-derivative free
    Chebyshev-Halley type methods with optimal eighth order convergence" creado por 
    Alicia Cordero, Munish Kansal, Vinay Kanwar y Juan R. Torregrosa. Esta versión intenta 
    lograr valores de conversión en el orden de 8 comparado a el quinto logrado con el original, ecuación 2.1 del documento.
    Para efectos de probar el método, se utilizó la función x^3+4*(x^2)-10 con un valor incial de 1.
    Prueba sne_ud_3("x^3+4*x^2-10", 1,0.0001,1)
    Parametros: 
    	1) func: Funcion en formato string en terminos de x la cual require la aproximacion
        2) x0: Valor inicial de la funcion necesario para las siguientes aproximaciones
        3) tol: Tolerancia al error maxima para el cálculo de la aproximacion
        4) graf: Bandera para realizar o no el grafico de iteraciones vs aproximacion.
    """
    x = Symbol("x")
    try:
        f = sympify(func)
        firstDerivate = diff(f, x)
        secondDerivate = diff(firstDerivate, x)
    except:
        print("Syntax Error")
        return
    xAxis = []
    yAxis = []
    aprox = x0
    iteration = 1
    while (abs(f.subs(x, aprox)) >= tol):
        functionAprox = f.subs(x, aprox)
        firstDerivateAprox = firstDerivate.subs(x, aprox)
        try:
            lF = Lf(f, firstDerivate, secondDerivate, aprox)
            zn = aprox - (1 + 0.5 * (lF/1-lF)) * \
                functionAprox/firstDerivateAprox
            temp = zn - f.subs(x, zn)/firstDerivate.subs(x, zn)
        except:
            break
        aprox = temp
        xAxis += [iteration]
        yAxis += [f.subs(x, aprox)]
        iteration += 1
    if (graf == 1):
        plt.plot(xAxis, yAxis)
        plt.title(
            'Iteration vs aproximation graph using a tol value of: ' + str(tol))
        plt.xlabel("iterations")
        plt.ylabel("Aproximation")
        plt.show()
        return [aprox, iteration]
    else:
        return "Iteration numeber:" + str(iteration) + " Aproximation value: " + str(aprox)


def sne_ud_6(fstr, x0, m, tol, graf):
    """Evalua una funcion dependiente de X para asi encontrar una aproximacion
    de una de sus raices.
    
    Recuperado de "Multiplicity anomalies of an optimal fourth-order class of
    iterative methods for solving nonlinear equations"
    Ecuacion 1
    Autores "Ramandeep Behl, Alicia Cordero, Sandile S. Motsa, Juan R. Torregrosa"
    Retorna una lista donde sus elementos son el x aproximado y la cantidad de
    iteraciones necesarias para cumplir con la tolerancia dada
    Parametros:
    fstr: funcion dependdiente de x a la cual se le quiere encontrar sus ceros
    x0: valor inicial para empezar a calcular las iteraciones
    m: constante necesario para calcular x
    tol: tolerancia aceptable para finalizar el metodo
    graf: parametro para indicar si se quiere generar la grafica
    PRUEBA sne_ud_6('x**2', 2, 1, 0.0001, 1)
    """

    lista = []
    retorno = metodo_iterativo6(fstr, x0, m, tol, 0, lista, graf)
    return retorno


def metodo_iterativo6(fstr, xn, m, tol, iteracion, arreglo, graf):
    """Evalua una funcion dependiente de X para asi encontrar una aproximacion
    de una de sus raices.
    
    Recuperado de "Multiplicity anomalies of an optimal fourth-order class of
    iterative methods for solving nonlinear equations"
    Ecuacion 1
    Autores "Ramandeep Behl, Alicia Cordero, Sandile S. Motsa, Juan R. Torregrosa"
    Retorna una lista donde sus elementos son el x aproximado y la cantidad de
    iteraciones necesarias para cumplir con la tolerancia dada
    Parametros:
    fstr: funcion dependdiente de x a la cual se le quiere encontrar sus ceros
    xn: valor inicial para empezar a calcular las iteraciones
    m: constante necesario para calcular x
    tol: tolerancia aceptable para finalizar el metodo
    iteracion: cantida de veces que se ha tratado de aproximar x
    arreglo: es un arreglo de arreglos donde se almacena los valores de
    las iteracciones y los valores de la función evaluada en xnueva
    graf: parametro para indicar si se quiere generar la grafica
    """
    x = sp.symbols('x')
    try:
        fun_sim = parse_expr(fstr)
    except:
        print('Error de sintaxis')
    arreglo_x = []
    arreglo_y = []
    arreglo_total = []
    if(len(arreglo) > 0):
        arreglo_total = arreglo
        arreglo_x = arreglo[0]
        arreglo_y = arreglo[1]
        arreglo_total = []

    if (abs(fun_sim.subs(x, xn)) <= tol):
        if (graf == 1):
            plt.plot(arreglo[0], arreglo[1])
            plt.show()
            return [xn, iteracion]
        else:
            return [xn, iteracion]
    else:
        derivada = sp.diff(fun_sim, x)
        yn = xn - ((2*m/(m+2)) * (fun_sim.subs(x, xn)/derivada.subs(x, xn)))
        xnueva = xn - (fun_sim.subs(x, xn)/(2*derivada.subs(x, xn)) *
                       (((m*(m-2))*((m/(m+2))**(-m))*derivada.subs(x, yn)-(m**2)*derivada.subs(x, xn))/(derivada.subs(x, xn)-((m/(m+2))**(-m))*derivada.subs(x, xn))))
        iteracion = iteracion + 1
        arreglo_x.append(xn)
        x = fun_sim.subs(x, xn)
        arreglo_y.append(iteracion)
        arreglo_total.append(arreglo_x)
        arreglo_total.append(arreglo_y)

        metodo_iterativo6(fstr, xnueva, m, tol, iteracion, arreglo_total, graf)


def evaluar(funcion, varx):
    """Evalúa una función dependiente de X, dado un valor.

    Devuelve el valor de la función correspondiente, al susituir
    su variable independiente X, por un valor 

    Parámetros:
    funcion   -- Funcion dependiente de X, a encontrar su valor
    varx      -- Valor de la variable X, a sustituir en la función dada
   
    """
    x, y, z = sp.symbols(
        'x y z')  # Define x,y,z como variables de una funcion
    # Evalua la funcion, indicado su variable y valor respectivo
    y = sp.sympify(funcion).subs(x, varx)
    return float(y)


def calDerivada(funcion):
    """Determina la derivada de una función dependiente de X.

    Devuelve el valor de la función derivada respecto a X

    Parámetros:
    funcion   -- Funcion dependiente de X, a derivar
   
    """
    x, y, z = sp.symbols(
        'x y z')  # Define x,y,z como variables de una funcion
    y = sp.sympify(funcion)  # Convierte el string funcion, a tipo Fucnion
    return y.diff(x)  # diff= utilizado para derivar la funcion, respecto a X


def error(funcion, xk):
    """Formúla que da el error en el método de la Falsa Posicion

    Devuelve el valor del error en una iteración específica del
    método de la Falsa Posicion

    Parámetros:
    x1     -- Valor anterior de la iteración
    x      -- Valor siguiente de la iteración
   
    """
    return evaluar(funcion, xk)


def imprimirResultado(iteraciones, valorAprox):
    print("Numero de iteraciones que se utilizaron para aproximar el cero : " + str(iteraciones+1))
    print("Aproximacion a la solucion de la ecuacion : " + str(valorAprox))


def graficar(listaX, listaY, nombre):
    """Gráfica de una ecuación no lineal mediante el método de Newton-Raphson.

    Parámetros:
    funcion -- Funcion dependiente de X, a cálcular su raíz
    listaX      -- Valor inicial dado
    listaY     -- Tolerancia miníma aceptada para encontrar la raíz
   
    """
    plt.plot(listaX, listaY, marker='o', color='b')
    plt.title('Comportamiento del metodo de ' + nombre)
    plt.xlabel('iteraciones')
    plt.ylabel('|f(Xaprox)|')
    plt.grid(True)
    plt.show()
