from setuptools import setup
setup( name ='SolNE',
    version = '0.1',
    description = 'Solving non linear equiations package',
    url = '#',
    author = 'Pol, Bryan, Nicko, Gaby',
    author_email = 'no hay',
    license = 'MIT',
    packages = ['SolNe'],
    zip_safe = True)