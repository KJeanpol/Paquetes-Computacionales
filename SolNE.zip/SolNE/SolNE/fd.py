from Equation import Expression
import matplotlib.pyplot as plt
import general as g
import sympy as sp
from sympy.parsing.sympy_parser import parse_expr


def sne_fd_1(fstr, x0, tol, graf):
    """Evalua una funcion dependiente de X para asi encontrar una aproximacion
    de una de sus raices.

    Recuperado de "Steffensen type methods for solving nonlinear equations"
    ecuacion 4
    Autores "Alicia Cordero, José L. Hueso, Eulalia Martínez, Juan R. Torregrosa"

    Retorna una lista donde sus elementos son el x aproximado y la cantidad de
    iteraciones necesarias para cumplir con la tolerancia dada

    parametros:
    fstr: funcion dependdiente de x a la cual se le quiere encontrar sus ceros
    x0: valor inicial para empezar a calcular las iteraciones
    tol: tolerancia aceptable para finalizar el metodo
    graf: parametro para indicar si se quiere generar la grafica

    ejemplo: sne_fd_1('sin(x)**2-x**2+1', 5, 0.00000000001, 1)

    """
    try:
        f = Expression(fstr, ["x"])
    except ValueError:
        return 'Syntaxis de la funcion incorrecta'
    yn = x0 - ((2*f(x0)**2)/((f(x0+f(x0)))-(f(x0-f(x0)))))
    xn = x0 - ((2*f(x0)**2)/((f(x0+f(x0)))-(f(x0-f(x0)))))*((f(yn)-f(x0))/(2*f(yn)-f(x0)))
    itera = 0
    xAx = []
    yAx = []
    while (abs(f(xn)) >= tol):
        xAx += [itera]
        yAx += [abs(f(xn))]
        try:
            denominador1 = 1/(f(xn+f(xn)) - f(xn-f(xn)))
            denominador1 = denominador1**(-1)
        except ValueError:
            break
        yn = xn - ((2*f(xn)**2)/denominador1)
        try:
            denominador2 = 1/(2*f(yn)-f(xn))
            denominador2 = denominador2**(-1)
        except ValueError:
            break
        xn = xn - ((2*f(xn)**2)/denominador1)*((f(yn)-f(xn))/denominador2)
        itera += 1
    if (graf):
        print(xAx)
        print(yAx)
        plt.plot(xAx, yAx)
        plt.title('Comportamiento del metodo de ODF para ' + fstr) 
        plt.xlabel('iteraciones')
        plt.ylabel('|f(Xaprox)|')
        plt.grid(True)
        plt.show()
        return [xn, itera]
    else:
        return [xn, itera]


def sne_fd_2(fstr, x0, tol, graf):
    """Evalua una funcion dependiente de X para asi encontrar una aproximacion
    de una de sus raices.

    Recuperado de "Steffensen type methods for solving nonlinear equations"
    ecuacion 5
    Autores "Alicia Cordero, José L. Hueso, Eulalia Martínez, Juan R. Torregrosa"

    Retorna una lista donde sus elementos son el x aproximado y la cantidad de
    iteraciones necesarias para cumplir con la tolerancia dada

    parametros:
    fstr: funcion dependdiente de x a la cual se le quiere encontrar sus ceros
    x0: valor inicial para empezar a calcular las iteraciones
    tol: tolerancia aceptable para finalizar el metodo
    graf: parametro para indicar si se quiere generar la grafica

    ejemplo: sne_fd_2('sin(x)**2-x**2+1', 5, 0.00000000001, 1)

    """
    try:
        f = Expression(fstr, ["x"])
    except ValueError:
        return 'Syntaxis de la funcion incorrecta'
    yn = x0 - ((2*f(x0)**2)/((f(x0+f(x0)))-(f(x0-f(x0)))))
    zn = yn - ((yn-x0)/(2*f(yn)-f(x0)))*(f(yn))
    xn = zn - ((yn-x0)/(2*f(yn)-f(x0)))*(f(zn))
    itera = 0
    xAx = []
    yAx = []
    while (abs(f(xn)) >= tol):
        xAx += [itera]
        yAx += [abs(f(xn))]
        try:
            denominador1 = 1/(f(xn+f(xn)) - f(xn-f(xn)))
            denominador1 = denominador1**(-1)
        except ValueError:
            break
        yn = xn - ((2*f(xn)**2)/denominador1)
        try:
            denominador2 = 1/(2*f(yn)-f(xn))
            denominador2 = denominador2**(-1)
        except ValueError:
            break
        zn = yn - ((yn-xn)/denominador2)*(f(yn))
        xn = zn - ((yn-xn)/denominador1)*(f(zn))
        itera += 1
    if (graf):
        plt.plot(xAx, yAx)
        plt.title('Comportamiento del metodo de IODF para ' + fstr) 
        plt.xlabel('iteraciones')
        plt.ylabel('|f(Xaprox)|')
        plt.grid(True)
        plt.show()
        return [xn, itera]
    else:
        return [xn, itera]


def getyk(funcion, xk):

    zk = getzk(funcion, xk)
    numerador = pow(g.evaluar(funcion, xk), 2)
    denominador = g.evaluar(funcion, zk)-g.evaluar(funcion, xk)
    yk = xk - (numerador/(denominador))
    return abs(yk)


def getzk(funcion, xk):
    zk = xk + g.evaluar(funcion, xk)
    return zk


def getxk(funcion, x):
    a = 1
    b = 1
    c = 1
    d = 0
    try:
        yk = getyk(funcion, x)
        zk = getzk(funcion, x)
        operando1 = (a*g.evaluar(funcion, yk)-b *
                     g.evaluar(funcion, zk))/abs(yk-zk)
        operando2 = (c*g.evaluar(funcion, yk) -
                     (d*g.evaluar(funcion, x)))/abs(yk-x)
        numerador = g.evaluar(funcion, yk)
        denominador = operando1+operando2
        xk = yk-(numerador/abs(denominador))
        return xk
    except:
        return True


def sne_fd_3(funcion, x0, tol, graf):
    """ Version del metodo iterativo de Steffensen con a=b=c=1 y d =0
       Recuperado del documento "A class of Steffensen type methods with optimal order of convergence" 
       creado por "Alicia Cordero, Juan R. Torregrosa" 
   Intenta lograr valores de conversion mediante la ecuacion (6) del documento.
   
   Parametros: 
    1) funcion: Funcion en formato string en terminos de x la cual require la aproximacion
    2) x0: Valor inicial de la funcion necesario para las siguientes aproximaciones
    3) tol: Tolerancia al error maxima para el cÃƒÂ¡lculo de la aproximacion
    4) graf: Bandera para realizar o no el grafico de iteraciones vs aproximacion.
   Probado con sne_fd_3("x**3+ 4*x**2- 10", 1.5, 0.000001, 1)
    """
    x = sp.symbols('x')
    try:
        fun_sim = parse_expr(funcion)
    except:
        print('Error de sintaxis')
    xk = getxk(funcion, x0)
    k = 1  # Corresponde a la iteraciÃ³n en que se encuentra
    listaX = [0]
    listaY = [x0]
    listaY.append(xk)
    listaX.append(1)
    while (g.error(funcion, xk) >= tol):
        xk = getxk(funcion, xk)
        xk1 = getxk(funcion, xk)
        if (xk1 == True):
            break
        else:
            listaY.append(xk)
            listaY.append(xk1)
            k += 2
            listaX.append(k-1)
            listaX.append(k)
    if (graf == 0):
        return g.imprimirResultado(listaX[-1], listaY[-1])
    else:
        print(listaX, listaY)
        g.imprimirResultado(listaX[-1], listaY[-1])
        return g.graficar(listaX, listaY, "Steffensen")


def getFZX(funcion, zk, xk):
    numerador = g.evaluar(funcion, zk) - g.evaluar(funcion, xk)
    denominador = zk - xk
    fzx = numerador/abs(denominador)
    return fzx

def getXk(funcion, xk):
    zk = getzk(funcion, xk)
    yk = getyk(funcion, xk)
    numerador = g.evaluar(funcion, yk)
    denominador = getFZX(funcion, zk, xk)
    xk = yk - (numerador/denominador)
    return xk


def sne_fd_4(funcion, x0, tol, graf):
    """Version del metodo iterativo de Traub con a=b=c=1 y d =0
       Recuperado del documento "Low-complexity root-finding iteration functions with no
       derivatives of any order of convergence" 
       creado por "Alicia Cordero, Juan R. Torregrosa" 
   
   Intenta lograr valores de conversion mediante la ecuacion (6) del documento.
   Parametros: 
    1) funcion: Funcion en formato string en terminos de x la cual require la aproximacion
    2) x0: Valor inicial de la funcion necesario para las siguientes aproximaciones
    3) tol: Tolerancia al error maxima para el cÃƒÂ¡lculo de la aproximacion
    4) graf: Bandera para realizar o no el grafico de iteraciones vs aproximacion.
    Probado con sne_fd_4("x**2-4*x+4",5, 0.000001, 1)
    """
    x = sp.symbols('x')
    try:
        fun_sim = parse_expr(funcion)
    except:
        print('Error de sintaxis')
    xk = getXk(funcion, x0)
    k = 1  # Corresponde a la iteraciÃ³n en que se encuentra
    listaX = [0]
    listaY = [x0]
    listaY.append(xk)
    listaX.append(1)
    while (abs(g.error(funcion, xk)) >= tol):
        xk = getXk(funcion, xk)
        if (xk == True):
            xk1 = getXk(funcion, xk)
            listaY.append(xk)
            listaY.append(xk1)
            k += 2
            listaX.append(k-1)
            listaX.append(k)
    if (graf == 0):
        return g.imprimirResultado(listaX[-1], listaY[-1])
    else:
        g.imprimirResultado(listaX[-1], listaY[-1])
        return g.graficar(listaX, listaY, "Traub Method")


def sne_fd_5(fstr, x0, p0, tol, graf):
    """Evalua una funcion dependiente de X para asi encontrar una aproximacion
    de una de sus raices.

    Recuperado de "A general class of four parametric with- and without
    memory iterative methods for nonlinear equations"
    Ecuacion: la primera ecuaciรณn que aparece 
    Autores "Fiza Zafar1, Alicia Cordero, Juan R. Torregrosa"
    Retorna una lista donde sus elementos son el x aproximado y la cantidad de
    iteraciones necesarias para cumplir con la tolerancia dada

    Parametros:
    fstr: funcion dependdiente de x a la cual se le quiere encontrar sus ceros
    x0: valor inicial para empezar a calcular las iteraciones
    p0: valor inicial para emperzar a calcular las iteraciones
    tol: tolerancia aceptable para finalizar el metodo
    graf: parametro para indicar si se quiere generar la grafica

    PRUEBA sne_fd_5('x**2', 2, 1, 0.0001,0)
    """
    lista = []
    retorno = metodo_interactivo5(fstr, x0, 0, p0, tol, 0, lista, graf)
    return retorno


def metodo_interactivo5(fstr, xn, xv, pn, tol, iteracion, arreglo, graf):
    """Evalua una funcion dependiente de X para asi encontrar una aproximacion
    de una de sus raices.

    Recuperado de "A general class of four parametric with- and without
    memory iterative methods for nonlinear equations"
    Ecuacion: la primera ecuaciรณn que aparece 
    Autores "Fiza Zafar1, Alicia Cordero, Juan R. Torregrosa"
    Retorna una lista donde sus elementos son el x aproximado y la cantidad de
    iteraciones necesarias para cumplir con la tolerancia dada

    Parametros:
    fstr: funcion dependdiente de x a la cual se le quiere encontrar sus ceros
    xn: valor inicial para empezar a calcular las iteraciones
    xv: valor anterior de x
    pn: valor inicial para emperzar a calcular las iteraciones
    tol: tolerancia aceptable para finalizar el metodo
    iteracion: numero de veces que se ha tratado de encontrar x
    arreglo: es un arreglo de arreglos donde se almacena los valores de
    las iteracciones y los valores de la funciรณn evaluada en xnueva
    graf: parametro para indicar si se quiere generar la grafica
    """
    x = sp.symbols('x')
    try:
        fun_sim = parse_expr(fstr)
    except:
        print('Error de sintaxis')
    arreglo_x = []
    arreglo_y = []
    arreglo_total = []
    if(len(arreglo) > 0):
        arreglo_total = arreglo
        arreglo_x = arreglo[0]
        arreglo_y = arreglo[1]
        arreglo_total = []

    if (pn != 0):
        if (abs(fun_sim.subs(x, xn)) <= tol):
            if (graf == 1):
                plt.plot(arreglo[0], arreglo[1])
                plt.show()
                return [xn, iteracion]
            else:
                return [xn, iteracion]
        else:
            wn = xn + pn*(fun_sim.subs(x, xn))
            xnueva = xn - (fun_sim.subs(x, xn) /
                           ((fun_sim.subs(x, xn)-fun_sim.subs(x, wn))/(xn-wn)))
            N = fun_sim.subs(x, xv) + (x - xnueva) * \
                ((fun_sim.subs(x, xnueva)-fun_sim.subs(x, xn))/(xnueva-xn))
            derivada = sp.diff(N, x)
            pnueva = -1/derivada
            iteracion = iteracion + 1
            arreglo_x.append(xn)
            x = fun_sim.subs(x, xn)
            arreglo_y.append(iteracion)
            arreglo_total.append(arreglo_x)
            arreglo_total.append(arreglo_y)

            metodo_interactivo5(fstr, xnueva, xn, pnueva,
                                tol, iteracion, arreglo_total, graf)


def sne_fd_6(fstr, xn, alpha1, alpha2, tol, graf):
    """Evalua una funcion dependiente de X para asi encontrar una aproximacion
    de una de sus raices.
    
    Recuperado de "Dynamical Techniques for Analyzing Iterative
    Schemes with Memory"
    Ecuacion 4
    Autores "Neha Choubey,A. Cordero, J. P. Jaiswal, and J. R. Torregrosa"
    
    Retorna una lista donde sus elementos son el x aproximado y la cantidad de
    iteraciones necesarias para cumplir con la tolerancia dada.
    
    Parรกmetros:
    fstr: funcion dependdiente de x a la cual se le quiere encontrar sus ceros
    xn: valor inicial para empezar a calcular las iteraciones
    alpha1: constante necesario para calcular x
    alpha2: constante necesario para calcular x
    tol: tolerancia aceptable para finalizar el metodo
    graf: parametro para indicar si se quiere generar la grafica

    PRUEBA sne_ud_6('x**2', 2, 1, 2, 0.0001,1)
    """

    lista = []

    retorno = metodo_recursivo6(fstr, xn, alpha1, alpha2, tol, lista, 0, graf)
    return retorno


def metodo_recursivo6(fstr, xn, alpha1, alpha2, tol, arreglo, iteracion, graf):
    """Evalua una funcion dependiente de X para asi encontrar una aproximacion
    de una de sus raices.
    
    Recuperado de "Dynamical Techniques for Analyzing Iterative
    Schemes with Memory"
    Ecuacion 4
    Autores "Neha Choubey,A. Cordero, J. P. Jaiswal, and J. R. Torregrosa"
    
    Retorna una lista donde sus elementos son el x aproximado y la cantidad de
    iteraciones necesarias para cumplir con la tolerancia dada.
    
    Parรกmetros:
    fstr: funcion dependdiente de x a la cual se le quiere encontrar sus ceros
    xn: valor inicial para empezar a calcular las iteraciones
    alpha1: valor necesario para encontrar el x aproximado
    alpha2: valor necesario para encontrar el x aproximado
    tol: tolerancia aceptable para finalizar el metodo
    arreglo: es un arreglo de arreglos donde se almacena los valores de
    las iteracciones y los valores de la funciรณn evaluada en xnueva
    iteracion: cantida de veces que se ha tratado de aproximar x
    graf: parametro para indicar si se quiere generar la grafica
    """
    x = sp.symbols('x')
    try:
        fun_sim = parse_expr(fstr)
    except:
        print('Error de sintaxis')

    arreglo_x = []
    arreglo_y = []
    arreglo_total = []
    if(len(arreglo) > 0):
        arreglo_total = arreglo
        arreglo_x = arreglo[0]
        arreglo_y = arreglo[1]
        arreglo_total = []

    if (abs(fun_sim.subs(x, xn)) <= tol):
        if (graf == 1):
            plt.plot(arreglo[0], arreglo[1])
            plt.show()
            return [xn, iteracion]

        else:
            return [xn, iteracion]
    else:
        derivada = sp.diff(fun_sim, x)
        yn = xn - (fun_sim.subs(x, xn)/derivada.subs(x, xn))
        zn = yn-(-derivada.subs(x, xn)+2 *
                 ((fun_sim.subs(x, yn)-fun_sim.subs(x, xn))/(yn-xn)))
        xnueva = fun_sim.subs(x, zn)/((alpha1*((fun_sim.subs(x, yn)-fun_sim.subs(x, xn))/(yn-xn))) +
                                      (alpha2*(fun_sim.subs(x, zn)-fun_sim.subs(x, yn))/(zn-yn))+(1-alpha1-alpha2) *
                                      ((fun_sim.subs(x, zn)-fun_sim.subs(x, xn))/(zn-xn)))
        iteracion = iteracion + 1
        arreglo_x.append(xn)
        x = fun_sim.subs(x, xn)
        arreglo_y.append(iteracion)
        arreglo_total.append(arreglo_x)
        arreglo_total.append(arreglo_y)

        metodo_recursivo6(fstr, xnueva, alpha1, alpha2, tol, arreglo_total, iteracion, graf)
